// animation files, given below are the coordinates. We are making an array with different positions.
var config = {
	pallet : {
		size :30                          
	},
	positions : [
		{
			x:10,                         
			y:65
		},
		{
			x:135,
			y:65
		},
		{
			x:195,
			y:65
		},
		{
			x:245,
			y:7
		},
		{
			x:375,
			y:65
		},
		{
			x:490,
			y:65
		},
	]
}

var pallets = [1,1,1,1,1];
var pallet;



/**function to add a pallet. 
*/
function add_pallet(){
	
	var svg = d3.select('svg'); // get root svg object to add pallets in it
	pallet = svg.append('rect') // create a pallet and assign to the pallet 
		.attr("x" , config.positions[0].x) 		// NB! as you can see prev line does not have semicolon
		.attr("y" , config.positions[0].y) 		// NB! and in current lines you are using .attr()
		.attr("width" , config.pallet.size) 	// NB! which means that the operatiosn will be done on
		.attr("height" , config.pallet.size); 	// NB! the same object.
};

/**funciton to animate the movement
*/
function move_pallet12(){
	pallet.transition() 
		.attr("x",config.positions[1].x) 	
		.attr("y",config.positions[1].y)
		.duration(1000);					
		
		
};
function move_pallet23(){
	pallet.transition() 
		.attr("x",config.positions[2].x) 	
		.attr("y",config.positions[2].y)
		.duration(1000);					
};
function move_pallet35(){
	pallet.transition() 
		.attr("x",config.positions[4].x) 	
		.attr("y",config.positions[4].y)
		.duration(1000);					
};
function move_pallet14(){
	pallet.transition()
		.attr("x",config.positions[3].x) 	
		.attr("y",config.positions[3].y)
		.duration(1000);					
};
function move_pallet45(){
	pallet.transition() 
		.attr("x",config.positions[4].x) 	
		.attr("y",config.positions[4].y)
		.duration(1000);					
};
function eject_pallet(){
	pallet.transition() 
		.attr("x",config.positions[5].x) 	
		.attr("y",config.positions[5].y)
		.duration(1000);					
};					
function delete_all_pallets(){
 pallet.remove();
};