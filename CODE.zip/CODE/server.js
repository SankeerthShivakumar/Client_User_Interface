var express = require('express');
var app = express();
//making server here 
var http = require('http').Server(app);
// to communicate with our client UI we use this 
var io = require('socket.io')(http);

// using body parser - analyses the responses
var bodyParser = require('body-parser')
app.use(bodyParser.json());

// using node rest client, get , post methods
var Client = require('node-rest-client').Client;
client = new Client();
  var emitSocket;
  
//write your ip here : Attension! It works with TUT universities IP!!
var argument = {
    data: { "destUrl": "http://130.230.157.187:3000" },
    headers: { "Content-Type": "application/json" }
};

//this route is from localhost:3000
app.get('/', function (req, res) {
    res.sendFile(__dirname + '/index.html');
});


//Defining resource filter from /js
app.use('/js', express.static(__dirname + '/js'))


//Running server on port 3000. here the local host is waiting to connect to client.
http.listen(3000, function()
			  {
	console.log('Started on port 3000....YO!');
});

//subscribing for the data
client.get("http://escop.rd.tut.fi:3000/RTU/CNV8/events/", function (data, response) {

    client.post("http://escop.rd.tut.fi:3000/RTU/CNV8/events/Z1_Changed/notifs", argument, function (data, response) { console.log("z1" + data);
    });
    client.post("http://escop.rd.tut.fi:3000/RTU/CNV8/events/Z2_Changed/notifs", argument, function (data, response) { console.log("z2" + data);
    });
    client.post("http://escop.rd.tut.fi:3000/RTU/CNV8/events/Z3_Changed/notifs", argument, function (data, response) { console.log("z3" + data);
    });
    client.post("http://escop.rd.tut.fi:3000/RTU/CNV8/events/Z4_Changed/notifs", argument, function (data, response) { console.log("z4" + data);
    });
    client.post("http://escop.rd.tut.fi:3000/RTU/CNV8/events/Z5_Changed/notifs", argument, function (data, response) { console.log("z5" + data);
    });
});

// we have used socket.io here, socket.on listens to the port if any event comes to the socket it checks with the value and
// posts back.
io.on('connection', function (socket) {
    
    console.log('socket connection established');
    socket.on('disconnect', function () {
        console.log('user disconnected');
    });
	
socket.on('add_pallet', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/ROB7/services/LoadPallet", argument, function (data, response) { console.log("add_pallet data -" + data);
        });
        
        
	var myVar = setTimeout(myTimer, 1000);
    });


function myTimer() {
    client.post("http://130.230.141.228:3000/RTU/CNV7/services/TransZone35", argument, function (data, response) { console.log("add_pallet data -" + data);
        }); 
}
    
    
socket.on('move_pallet12', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/CNV8/services/TransZone12", argument, function (data, response) { console.log("Transzone12 data -" + data);
        });

    });

	

socket.on('delete_all_pallets', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        argument = {};
        client.post("http://130.230.141.228:3000/RTU/reset", argument, function (data, response) {console.log("data delete request from server - " + data);
        });

    });


socket.on('move_pallet23', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/CNV8/services/TransZone23", argument, function (data, response) {console.log("transfer 2-3 data -" + data);
        });

    });

socket.on('move_pallet14', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/CNV8/services/TransZone14", argument, function (data, response) {console.log("transfer 1-4 data -" + data);
        });

    });
 
socket.on('move_pallet35', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/CNV8/services/TransZone35", argument, function (data, response) {console.log("transfer 3-5 data -" + data);
        });

    });

socket.on('move_pallet45', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/CNV8/services/TransZone45", argument, function (data, response) { console.log("transfer 4-5 data -" + data);
        });

    });

socket.on('eject_pallet', function (msg) {
        var Client = require('node-rest-client').Client;
        client = new Client();
        client.post("http://130.230.141.228:3000/RTU/CNV9/services/TransZone12", argument, function (data, response) { console.log("system cleared" + data);
        });

    });
    
    //here we define behaviour of server if anything is POST on the server at localhost.
    //POST is done either by User by clicking the button on Client user interface (index.html) or when the simulator posts notification to the server.
    app.post('/', function (req, res) {
    //emitSocket is used to send information from server.js to our interface.
        emitSocket = socket;
             var RawData = req.body;
        
        
        if (req.body.id == "Z1_Changed") {
            //this message is actually a notification from simulator.
            //Hence we forward the occurence of this event to the index.html by using emit function.
           console.log("Sending " + req.body.id);
           emitSocket.emit('Change1', {
            zone: req.body.id           
        });           
        }
        else if (req.body.id == "Z2_Changed") {
           console.log("Sending " + req.body.id);
           emitSocket.emit('Change2', {
            zone: req.body.id           
        });           
        }
        else if (req.body.id == "Z3_Changed") {
           console.log("Sending " + req.body.id);
           emitSocket.emit('Change3', {
            zone: req.body.id           
        });           
        }
       else if (req.body.id == "Z4_Changed") {
           console.log("Sending " + req.body.id);
           emitSocket.emit('Change4', {
            zone: req.body.id           
        });           
        }
        else if (req.body.id == "Z5_Changed") {
           console.log("Sending " + req.body.id + "and " + req.body.payload.PalletID);
           emitSocket.emit('Change5', {
            zone: req.body.id,
            palletId: req.body.payload.PalletID
        });           
        }
          

        //Whenever a user clicks a button or when server recieves a notificatin, we are posting to different zones to get the pallet ID and then show it on the user interface.
       //For zone 1
       client.post("http://130.230.141.228:3000/RTU/CNV8/services/Z1", argument, function (data, response) { console.log("zone1 data " + JSON.parse(data).PalletID);
                    emitSocket.emit('zone1', {
            palletID: JSON.parse(data).PalletID          
        });              
       });
       //For zone 2
       client.post("http://130.230.141.228:3000/RTU/CNV8/services/Z2", argument, function (data, response) { console.log("zone2 data" + data);
       emitSocket.emit('zone2', {
            palletID: JSON.parse(data).PalletID          
        });
       
       });
       //For zone 3
       client.post("http://130.230.141.228:3000/RTU/CNV8/services/Z3", argument, function (data, response) { console.log("zone3 data" + data);
       emitSocket.emit('zone3', {
            palletID: JSON.parse(data).PalletID          
        });
       });
       //for zone 4
       client.post("http://130.230.141.228:3000/RTU/CNV8/services/Z4", argument, function (data, response) { console.log("zone4 data" + data);
       emitSocket.emit('zone4', {
            palletID: JSON.parse(data).PalletID          
        });
       });
       // for zone 5
      client.post("http://130.230.141.228:3000/RTU/CNV8/services/Z5", argument, function (data, response) { console.log("zone5 data" + data);
       emitSocket.emit('zone5', {
            palletID: JSON.parse(data).PalletID,
            
        });       
       });
         
        
        
        });

});


